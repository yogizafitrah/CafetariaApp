package com.cloudteam.crudfirebase.bind

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.cloudteam.crudfirebase.model.Products
import kotlinx.android.synthetic.main.item_list_products.view.*


//class UsersViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
//    fun bindItem(products: Products) {
//        view.apply {
//            val name_product = "Product Name   : ${products.strName}"
//            val category = "Category : ${products.strCategory}"
//            val price = "Price    : ${products.doublePrice.toString()}"
//
//            tv_name.text = name
//            tv_adress.text = addr
//            tv_age.text = age
//        }
//    }
//}